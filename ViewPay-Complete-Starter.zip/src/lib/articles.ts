export type Article = {
  slug: string;
  title: string;
  category: string;
  categorySlug: string;
  excerpt: string;
  published: string;
  readTime: string;
  intro: string;
  sections: { heading: string; paragraphs: string[]; bullets?: string[] }[];
};

export const articles: Article[] = [
  {
    slug: "side-hustles-start-with-1000-kenya",
    title: "10 Side Hustles You Can Start With KSh 1,000 in Kenya",
    category: "Side Hustles", categorySlug: "side-hustles",
    excerpt: "Small business ideas to research and test with limited starting capital.",
    published: "2026-11-20", readTime: "6 min read",
    intro: "Starting small can help you learn what customers need before committing more money. KSh 1,000 is a very limited budget, so treat these ideas as small experiments rather than guaranteed businesses.",
    sections: [
      { heading: "Ideas to consider", paragraphs: ["Choose an idea that fits your skills, location and the people you can realistically reach. Check local rules and costs before you begin."], bullets: ["Sell a small selection of seasonal fruit or vegetables.", "Prepare and sell a limited batch of snacks where permitted.", "Resell carefully selected second-hand items.", "Offer basic laundry or cleaning services.", "Make simple handmade accessories.", "Sell phone accessories after checking supplier quality.", "Offer typing, formatting or other digital services if you have access to a suitable device.", "Provide errands or local delivery within a small area.", "Grow fast-moving herbs or seedlings where space allows.", "Help nearby small businesses with simple product photos or social posts."] },
      { heading: "Plan before spending", paragraphs: ["Write down the full cost of stock, transport, packaging, mobile data and any required permits. Start with a small test, keep receipts and record every sale. Do not borrow money you cannot comfortably repay."] },
      { heading: "Measure the result", paragraphs: ["Calculate profit after all costs, not just the difference between the buying and selling price. If customers return and the numbers make sense, consider reinvesting a portion of actual profit."] }
    ]
  },
  {
    slug: "save-10000-small-salary",
    title: "How to Work Towards Saving KSh 10,000 on a Small Salary",
    category: "Money Tips", categorySlug: "money-tips",
    excerpt: "A realistic budgeting approach for building savings without ignoring essential expenses.",
    published: "2026-11-20", readTime: "5 min read",
    intro: "Saving KSh 10,000 every month may be possible for some households and unrealistic for others. The right target depends on income, rent, food, transport, dependants and existing obligations.",
    sections: [
      { heading: "Start with your real numbers", paragraphs: ["Track income and spending for one month. Include small daily purchases, airtime, transport, fees and irregular bills. A budget based on guesses is difficult to follow."] },
      { heading: "Set a sustainable target", paragraphs: ["Pay essential expenses first. Choose a weekly or monthly savings amount that does not force you to skip food, healthcare, rent or debt obligations. Increase it only when your budget can support it."] , bullets: ["Separate needs from optional spending.", "Plan meals and shopping before going to the market.", "Compare transport and service costs where practical.", "Set aside money for predictable annual expenses.", "Review your budget at the end of each month."] },
      { heading: "Protect your savings", paragraphs: ["Keep emergency money somewhere secure and accessible. Be cautious of schemes promising unusually high or guaranteed returns. This article is general education, not personal financial advice."] }
    ]
  },
  {
    slug: "choosing-budget-phone-kenya",
    title: "How to Choose a Good Phone on a Budget in Kenya",
    category: "Technology", categorySlug: "technology",
    excerpt: "What to compare before buying an affordable smartphone.",
    published: "2026-11-20", readTime: "5 min read",
    intro: "Phone prices and stock change frequently. Rather than relying on a fixed list that can become outdated, compare the specifications and support offered by the exact model available from the seller.",
    sections: [
      { heading: "Check the essentials", paragraphs: ["Look at battery capacity, RAM, storage, screen quality, camera performance and the processor. More advertised megapixels do not automatically mean better photos."] , bullets: ["Choose enough storage for your apps and files.", "Check whether storage can be expanded.", "Ask how long software and security updates are expected.", "Check network-band compatibility and 4G/5G support.", "Inspect the charging port, screen and battery condition on used devices."] },
      { heading: "Buy carefully", paragraphs: ["Compare prices from reputable sellers, request a receipt and confirm the warranty and return terms. Avoid paying in advance to unknown sellers based only on social-media adverts."] }
    ]
  },
  {
    slug: "compare-mobile-data-kenya",
    title: "How to Compare Mobile Data Bundles in Kenya",
    category: "Technology", categorySlug: "technology",
    excerpt: "Compare data value, validity and coverage instead of looking at price alone.",
    published: "2026-11-20", readTime: "4 min read",
    intro: "The best mobile data option depends on where you use your phone, how much data you need and how long a bundle remains valid. Prices and offers change, so check the operator's official channels before purchasing.",
    sections: [
      { heading: "Compare the full offer", paragraphs: ["Calculate the cost per gigabyte where possible, but also check validity, fair-use limits, rollover rules and whether the offer is restricted to certain apps or times."] },
      { heading: "Check coverage where you live", paragraphs: ["Ask people who use the networks in the exact places you visit. A low-cost bundle may not be useful if the signal is unreliable at home or work."] },
      { heading: "Avoid outdated prices", paragraphs: ["Treat screenshots and old articles as historical information. Confirm current prices and terms directly with Safaricom or Airtel before making a decision."] }
    ]
  },
  {
    slug: "affordable-dinner-ideas-kenya",
    title: "5 Affordable Dinner Ideas for a Tight Budget",
    category: "Food & Lifestyle", categorySlug: "lifestyle",
    excerpt: "Simple meal ideas that can be adjusted to seasonal prices and household needs.",
    published: "2026-11-20", readTime: "4 min read",
    intro: "Food prices vary by town, season, market and portion size. These are flexible meal ideas, not fixed-price promises.",
    sections: [
      { heading: "Simple meal combinations", paragraphs: ["Use locally available ingredients and adjust portions to the household. Wash produce properly and cook food thoroughly."], bullets: ["Ugali with sukuma wiki and beans.", "Rice with ndengu or beans.", "Githeri with seasonal vegetables.", "Potatoes with cabbage or other vegetables.", "Chapati with a modest serving of lentils when ingredients are affordable."] },
      { heading: "Make the budget go further", paragraphs: ["Plan several meals around overlapping ingredients, compare market prices and store dry foods safely. Do not compromise food safety to reduce costs."] }
    ]
  },
  {
    slug: "speed-up-android-phone-safely",
    title: "How to Improve a Slow Android Phone Without Deleting Photos",
    category: "Technology", categorySlug: "technology",
    excerpt: "Safe maintenance steps to try before considering a reset or deleting personal files.",
    published: "2026-11-20", readTime: "5 min read",
    intro: "A phone can slow down when storage is nearly full, many apps run in the background or software is outdated. Try low-risk steps first and back up important information before making major changes.",
    sections: [
      { heading: "Try these steps", paragraphs: ["Start with simple maintenance and check whether performance improves."], bullets: ["Restart the phone.", "Install system and app updates from official settings or stores.", "Remove apps you no longer use.", "Clear an individual app's cache through Android settings where available.", "Review large downloads and duplicate files before deleting anything.", "Move backed-up photos only after confirming the backup is complete."] },
      { heading: "Avoid risky cleaner apps", paragraphs: ["Be careful with apps that promise instant speed boosts, request excessive permissions or display intrusive adverts. Never share passwords or one-time verification codes with a cleaner app."] }
    ]
  }
];

export function getArticle(slug: string) {
  return articles.find((article) => article.slug === slug);
}
