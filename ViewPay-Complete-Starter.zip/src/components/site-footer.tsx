import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <div>
          <Link href="/" className="brand footer-brand">VIEW<span>PAY</span></Link>
          <p>Money tips, side hustles and useful guides for Kenya.</p>
        </div>
        <div className="footer-links">
          <Link href="/about">About</Link>
          <Link href="/contact">Contact</Link>
          <Link href="/privacy">Privacy Policy</Link>
          <Link href="/terms">Terms</Link>
          <Link href="/disclaimer">Disclaimer</Link>
        </div>
      </div>
      <div className="copyright">© {new Date().getFullYear()} ViewPay. All rights reserved.</div>
    </footer>
  );
}
