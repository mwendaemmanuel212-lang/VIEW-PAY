import Link from "next/link";

const links = [
  ["Home", "/"],
  ["Money Tips", "/category/money-tips"],
  ["Side Hustles", "/category/side-hustles"],
  ["Phones & Tech", "/category/technology"],
  ["About", "/about"],
  ["Contact", "/contact"]
];

export function SiteHeader() {
  return (
    <>
      <div className="top-strip">Practical ideas. Smarter everyday decisions.</div>
      <header className="site-header">
        <div className="header-inner">
          <Link href="/" className="brand" aria-label="ViewPay home">
            VIEW<span>PAY</span>
          </Link>
          <nav aria-label="Main navigation">
            {links.map(([label, href]) => <Link key={href} href={href}>{label}</Link>)}
          </nav>
        </div>
      </header>
    </>
  );
}
