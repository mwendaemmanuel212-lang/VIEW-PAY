import Link from "next/link";
export default function NotFound() { return <div className="content-page"><span className="eyebrow dark-eyebrow">404 ERROR</span><h1 className="page-title">This page could not be found.</h1><p className="page-lead">The link may be outdated or the page may have moved.</p><Link className="button button-dark" href="/">Return to ViewPay</Link></div>; }
