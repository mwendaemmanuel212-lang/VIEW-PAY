import type { Metadata } from "next";
export const metadata: Metadata = { title: "Contact ViewPay" };
export default function ContactPage() {
  const email = process.env.NEXT_PUBLIC_CONTACT_EMAIL || "REPLACE_WITH_YOUR_EMAIL";
  return <div className="content-page prose-page"><span className="eyebrow dark-eyebrow">GET IN TOUCH</span><h1 className="page-title">Contact ViewPay</h1><p className="page-lead">Questions, corrections or suggestions are welcome.</p><h2>Editorial and general enquiries</h2><p>Email: <a href={email.includes("@") && !email.startsWith("REPLACE") ? `mailto:${email}` : undefined}>{email}</a></p><p><strong>Website owner:</strong> ViewPay Editorial</p><p><strong>Location:</strong> Kenya</p><p>We will add our verified business contact details before applying to advertising networks. Please do not treat this placeholder as a working email address.</p></div>;
}
