import type { MetadataRoute } from "next";
import { articles } from "@/lib/articles";
export default function sitemap(): MetadataRoute.Sitemap {
  const site = process.env.NEXT_PUBLIC_SITE_URL || "https://viewpay-platform.workers.dev";
  const pages = ["", "/about", "/contact", "/privacy", "/terms", "/disclaimer"];
  return [
    ...pages.map((path) => ({ url: `${site}${path}`, lastModified: new Date() })),
    ...articles.map((article) => ({ url: `${site}/articles/${article.slug}`, lastModified: new Date(article.published) }))
  ];
}
