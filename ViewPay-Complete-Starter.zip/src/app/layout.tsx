import type { Metadata } from "next";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://viewpay-platform.workers.dev";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "ViewPay Kenya | Money Tips, Side Hustles & Smart Living",
    template: "%s | ViewPay Kenya"
  },
  description: "Practical money management, side-hustle ideas, technology guides and affordable living tips for readers in Kenya.",
  applicationName: "ViewPay",
  openGraph: {
    type: "website",
    siteName: "ViewPay",
    title: "ViewPay Kenya",
    description: "Money tips, side hustles and smart living guides for Kenya."
  },
  robots: { index: true, follow: true }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en-KE">
      <body>
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
