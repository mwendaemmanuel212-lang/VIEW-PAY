import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { articles, getArticle } from "@/lib/articles";

export function generateStaticParams() {
  return articles.map((article) => ({ slug: article.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const article = getArticle(slug);
  return article ? { title: article.title, description: article.excerpt } : {};
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = getArticle(slug);
  if (!article) notFound();
  return <div className="content-page">
    <div className="breadcrumbs"><Link href="/">Home</Link> / <span>{article.category}</span></div>
    <article className="reading">
      <span className="category-label">{article.category}</span>
      <h1>{article.title}</h1>
      <p className="article-deck">{article.excerpt}</p>
      <div className="meta article-meta">{article.readTime} · Published {article.published} · ViewPay Editorial</div>
      <div className="article-callout">{article.intro}</div>
      <div className="article-ad-note">ADVERTISEMENT — reserved placement</div>
      {article.sections.map((section) => <section key={section.heading}><h2>{section.heading}</h2>{section.paragraphs.map((p) => <p key={p}>{p}</p>)}{section.bullets && <ul>{section.bullets.map((b) => <li key={b}>{b}</li>)}</ul>}</section>)}
      <p className="editorial-note">Information is provided for general educational purposes. Verify prices, rules and service details with the relevant provider before acting.</p>
      <Link className="text-link" href="/">← Back to all guides</Link>
    </article>
  </div>;
}
