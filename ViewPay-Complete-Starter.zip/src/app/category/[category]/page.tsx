import type { Metadata } from "next";
import Link from "next/link";
import { articles } from "@/lib/articles";
const labels: Record<string, string> = { "money-tips": "Money Tips", "side-hustles": "Side Hustles", technology: "Phones & Technology" };
export function generateStaticParams() { return Object.keys(labels).map((category) => ({ category })); }
export async function generateMetadata({ params }: { params: Promise<{ category: string }> }): Promise<Metadata> {
  const { category } = await params;
  return { title: labels[category] || "Category" };
}
export default async function CategoryPage({ params }: { params: Promise<{ category: string }> }) {
  const { category } = await params;
  const label = labels[category];
  if (!label) return <div className="content-page"><h1>Category not found</h1><Link href="/">Return home</Link></div>;
  const items = articles.filter((a) => a.categorySlug === category);
  return <div className="content-page"><span className="eyebrow dark-eyebrow">EXPLORE VIEWPAY</span><h1 className="page-title">{label}</h1><p className="page-lead">Practical guides and useful information for Kenyan readers.</p><div className="compact-list">{items.map((a) => <article className="compact-card" key={a.slug}><div><span className="category-label">{a.category}</span><h3><Link href={`/articles/${a.slug}`}>{a.title}</Link></h3><p>{a.excerpt}</p></div><Link className="round-arrow" href={`/articles/${a.slug}`}>↗</Link></article>)}</div></div>;
}
