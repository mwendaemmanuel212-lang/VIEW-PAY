import Link from "next/link";
import { articles } from "@/lib/articles";

export default function HomePage() {
  const featured = articles.slice(0, 3);
  const more = articles.slice(3);
  return (
    <>
      <section className="hero">
        <div className="hero-content">
          <span className="eyebrow">WELCOME TO VIEWPAY</span>
          <h1>Make smarter moves<br /><span>with your money.</span></h1>
          <p>Practical money tips, side-hustle ideas and useful technology guides for everyday life in Kenya.</p>
          <Link className="button button-yellow" href="#latest">Explore our guides <span aria-hidden="true">→</span></Link>
        </div>
        <div className="hero-note"><strong>Useful information.</strong><span>Clear ideas for real-life decisions.</span></div>
      </section>
      <div className="ad-slot" aria-label="Advertisement area">
        <span>ADVERTISEMENT</span><small>Ad placement reserved — advertising code will be added only after provider approval.</small>
      </div>
      <section className="section-wrap" id="latest">
        <div className="section-heading"><div><span className="eyebrow dark-eyebrow">THE VIEWPAY EDIT</span><h2>Latest guides</h2></div><p>Helpful reads to inform your next decision.</p></div>
        <div className="article-grid">
          {featured.map((article, i) => (
            <article className="article-card featured-card" key={article.slug}>
              <div className={`card-art art-${i + 1}`}><span>{article.category}</span><b>{String(i + 1).padStart(2, "0")}</b></div>
              <div className="card-body"><div className="meta">{article.readTime} · {article.published}</div><h3><Link href={`/articles/${article.slug}`}>{article.title}</Link></h3><p>{article.excerpt}</p><Link className="text-link" href={`/articles/${article.slug}`}>Read article <span>→</span></Link></div>
            </article>
          ))}
        </div>
      </section>
      <div className="ad-slot ad-slot-wide"><span>ADVERTISEMENT</span><small>Reserved for a format approved for this website and its traffic.</small></div>
      <section className="section-wrap more-section">
        <div className="section-heading"><div><span className="eyebrow dark-eyebrow">MORE TO EXPLORE</span><h2>Fresh perspectives</h2></div></div>
        <div className="compact-list">
          {more.map((article) => <article className="compact-card" key={article.slug}><div><span className="category-label">{article.category}</span><h3><Link href={`/articles/${article.slug}`}>{article.title}</Link></h3><p>{article.excerpt}</p></div><Link className="round-arrow" href={`/articles/${article.slug}`} aria-label={`Read ${article.title}`}>↗</Link></article>)}
        </div>
      </section>
      <section className="newsletter-band"><div><span className="eyebrow">VIEWPAY</span><h2>Better information.<br />Better everyday choices.</h2><p>Explore practical guides created for Kenyan readers.</p></div><Link className="button button-dark" href="/about">Get to know us <span>→</span></Link></section>
    </>
  );
}
