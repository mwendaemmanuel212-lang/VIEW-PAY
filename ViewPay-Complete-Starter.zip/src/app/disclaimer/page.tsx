import type { Metadata } from "next";
export const metadata: Metadata = { title: "Disclaimer" };
export default function DisclaimerPage() {
  return <div className="content-page prose-page"><span className="eyebrow dark-eyebrow">IMPORTANT INFORMATION</span><h1 className="page-title">Disclaimer</h1><p>ViewPay publishes general educational information. Content is not a promise of employment, earnings, investment returns, product performance or savings.</p><p>Side-hustle examples involve costs, risks and local requirements. Research and verify before spending money or starting an activity.</p><p>Third-party advertisements are controlled by their respective providers and advertisers. ViewPay does not guarantee the quality or claims of every advertised product or service.</p><p>We will clearly identify paid placements or sponsored material where applicable.</p></div>;
}
