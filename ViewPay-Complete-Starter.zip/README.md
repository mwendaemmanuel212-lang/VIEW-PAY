# ViewPay

ViewPay is a Kenyan-focused publication covering practical money management, side hustles, technology and affordable living.

## Stack
- Next.js App Router
- TypeScript
- Cloudflare Workers using the OpenNext adapter

## Local development
1. Install Node.js 20.19+ or 22.12+ and npm.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local` and set the real contact email and public URL.
4. Run `npm run dev`.

## Cloudflare
The project is configured for Cloudflare Workers with OpenNext.
- Preview: `npm run preview`
- Deploy: `npm run deploy`

Connect this GitHub repository to Cloudflare Workers Builds and configure the build command and secrets according to the current Cloudflare OpenNext guide.

## Before advertising applications
- Replace the contact email placeholder with a monitored inbox.
- Verify every article, fact, price and external link; add author/editor details and publish dates.
- Add a real cookie/consent solution if required by the advertising providers and applicable law.
- Publish only original, useful content and build genuine traffic.
- Do not incentivize ad clicks or ordinary ad impressions. Use only reward formats for which the specific provider has explicitly approved incentivized traffic in writing.
- This starter does not claim that ViewPay is approved by any ad network.

## Important
This first release is the public publishing website foundation. Member accounts, sponsored task integrations, reward ledger and withdrawals are intentionally not enabled until the relevant providers, database, payment controls and compliance rules are confirmed.
